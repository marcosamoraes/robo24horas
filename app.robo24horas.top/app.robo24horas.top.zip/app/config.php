<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'whatsapp');
define('DB_PASS', 'sMSyEFr8Rymf4y7G');
define('DB_NAME', 'whatsapp');
define('TIMEZONE', 'Asia/Ho_Chi_Minh');
define('ENCRYPTION_KEY', 'fdc47de07c002c111041db8f96a0376a');