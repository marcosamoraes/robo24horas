<?php
return [
    'id' => 'email',
    'name' => 'Email',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'far fa-envelope',
    'color' => ''
];