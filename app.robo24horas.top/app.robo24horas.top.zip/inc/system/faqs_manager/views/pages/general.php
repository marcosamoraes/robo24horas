<div class="wrap-m h-100">
	<div class="empty">
		<div class="icon"></div>
		<a 
    		class="btn btn-info actionItem" 
    		data-result="html" 
    		data-content="column-two"
    		data-history="<?php _e( get_module_url('index/update') )?>" 
    		href="<?php _e( get_module_url('index/update') )?>"
    		data-call-after="Core.CKEditor();" 
    	>
    		<?php _e('Add new')?>
    	</a>
	</div>
</div>