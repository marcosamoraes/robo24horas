<div class="form-group">
    <label for="whatsapp_server_url"><?php _e('Whatsapp Server URL')?></label>
    <input type="text" class="form-control" id="whatsapp_server_url" name="whatsapp_server_url" value="<?php _e( get_option('whatsapp_server_url', '') )?>">
</div>