<?php
$lang["Success"] = "Success";
$lang["Dashboard"] = "Dashboard";
$lang["Search"] = "Search";
$lang["Report"] = "Report";