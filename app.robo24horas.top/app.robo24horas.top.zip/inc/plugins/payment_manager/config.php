<?php
return [
    'id' => 'payment_manager',
    'name' => 'Payment manager',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-money-check',
    'color' => '',
    'menu' => [
    	'tab' => 5,
    	'position' => 1500,
    	'name' => 'Payment manager'
    ],
    'css' => [
        'assets/css/payment_manager.css'
    ]
];