<?php
return [
    'id' => 'profile',
    'name' => 'Profile',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-user',
    'color' => '',
];