<?php
return [
    'id' => 'appearance',
    'name' => 'Appearance',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-palette',
    'color' => '',
];