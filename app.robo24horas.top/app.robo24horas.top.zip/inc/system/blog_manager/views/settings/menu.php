<div class="item widget-item search-item <?php _e( segment(3)==$path?'active':'' )?>">
	<a href="<?php _e( get_url('blog_manager') )?>">
		<span class="widget-section">
			<span class="widget-icon"><i class="fas fa-blog"></i></span>
			<span class="widget-desc"><?php _e('Blog manager')?></span>
		</span>
	</a>
</div>