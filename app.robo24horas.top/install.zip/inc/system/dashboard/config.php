<?php
return [
    'id' => 'dashboard',
    'name' => 'Dashboard',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-desktop',
    'color' => '#1ac958',
    'menu' => [
        'tab' => 1,
        'position' => 1100,
        'name' => 'Dashboard'
    ]
];