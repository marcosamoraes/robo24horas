<?php
return [
    'id' => 'faqs_manager',
    'name' => 'Faqs manager',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'far fa-question-circle',
    'menu' => [
    	'tab' => 5,
    	'position' => 1005,
    	'name' => 'Faqs manager'
    ]
];