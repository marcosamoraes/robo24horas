<?php
return [
    'id' => 'stripe_recurring',
    'name' => 'Stripe recurring',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => '',
    'color' => '#74788d',
];