<?php
$lang["Status"] = "Status";
$lang["Enable"] = "Enable";
$lang["Disable"] = "Disable";
$lang["Get Beamer product id at here:"] = "Get Beamer product id at here:";
$lang["Important:"] = "Important:";
$lang["Set field HTML SELECTOR is beamer-notification at here:"] = "Set field HTML SELECTOR is beamer-notification at here:";
$lang["Beamer product id"] = "Beamer product id";
$lang["Submit"] = "Submit";
$lang["Notification"] = "Notification";
$lang["Notification with Beamer"] = "Notification with Beamer";
$lang["Success"] = "Success";