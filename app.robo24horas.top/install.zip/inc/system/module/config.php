<?php
return [
    'id' => 'module',
    'name' => 'Module & Themes',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-puzzle-piece',
    'color' => '',
    'menu' => [
        'tab' => 5,
    	'position' => 1000,
    	'name' => 'Module & Themes',
    ]
];