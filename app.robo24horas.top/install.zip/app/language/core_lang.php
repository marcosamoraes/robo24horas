<?php
$lang["%s must be greater than or equal to %d"] = "%s must be greater than or equal to %d";
$lang["%s must be less than or equal to %d"] = "%s must be less than or equal to %d";
$lang["%s must be greater than or equal to %d characters"] = "%s must be greater than or equal to %d characters";
$lang["%s must be less than or equal to %d characters"] = "%s must be less than or equal to %d characters";
$lang["Email is not a valid email address"] = "Email is not a valid email address";
$lang["The url is not valid"] = "The url is not valid";
$lang["%s must be an string"] = "%s must be an string";
$lang["%s must be an array"] = "%s must be an array";
$lang["%s must be an object"] = "%s must be an object";
$lang["%s must not be an string"] = "%s must not be an string";
$lang["%s must not be an array"] = "%s must not be an array";
$lang["%s must not be an object"] = "%s must not be an object";
$lang["%s is required"] = "%s is required";