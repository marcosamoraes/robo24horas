<?php
return [
    'id' => 'others',
    'name' => 'Others',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-share-alt',
    'color' => '',
];