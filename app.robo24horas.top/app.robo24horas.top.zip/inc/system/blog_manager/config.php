<?php
return [
    'id' => 'blog_manager',
    'name' => 'Blog manager',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-blog',
    'menu' => [
    	'tab' => 5,
    	'position' => 1010,
    	'name' => 'Blog manager'
    ]
]; 