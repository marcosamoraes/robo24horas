<?php
$lang["Paypal"] = "Paypal";
$lang["Success"] = "Success";
$lang["You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method."] = "You are using the monthly payment plan. Cancel it if you want to change the package or change your payment method.";
$lang["Recurring payment"] = "Recurring payment";
$lang["Paypal recurring payment"] = "Paypal recurring payment";
$lang["Status"] = "Status";
$lang["Enable"] = "Enable";
$lang["Disable"] = "Disable";
$lang["Webhook URL:"] = "Webhook URL:";
$lang["Webhook ID"] = "Webhook ID";
$lang["Paypal recurring"] = "Paypal recurring";
$lang["Required events:"] = "Required events:";